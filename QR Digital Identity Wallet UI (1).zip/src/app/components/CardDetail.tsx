import { useParams, Link, useNavigate } from "react-router";
import { identityCards } from "../data/identityData";
import { ArrowLeft, QrCode, Calendar, Building2, Hash, Info, Download, Share2 } from "lucide-react";
import { motion } from "motion/react";

export function CardDetail() {
  const { cardId } = useParams<{ cardId: string }>();
  const navigate = useNavigate();
  const card = identityCards.find((c) => c.id === cardId);

  if (!card) {
    return (
      <div className="p-6 text-center bg-transparent min-h-screen flex items-center justify-center transition-colors duration-500">
        <div>
          <p className="text-slate-600 dark:text-slate-400 mb-4">Credential not found</p>
          <Link to="/" className="text-cyan-600 dark:text-cyan-400 hover:text-green-600 dark:hover:text-green-400 transition-colors tracking-[0.2em] text-[10px] font-bold uppercase">
            Return to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-transparent min-h-screen pb-20 md:pb-8 transition-colors duration-500">
      {/* Hero Section with Card Preview */}
      <div className="bg-gradient-to-b from-blue-100/40 dark:from-blue-950/20 to-transparent border-b border-blue-200/30 dark:border-blue-900/20">
        <div className="max-w-5xl mx-auto px-6 py-12">
          <Link to="/" className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors mb-12 group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] tracking-[0.2em] font-bold uppercase">Back to Dashboard</span>
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl md:text-5xl text-slate-800 dark:text-white mb-12 tracking-tight font-light">
              Credential Details
            </h1>

            {/* Premium Card Display */}
            <div className="relative max-w-2xl">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-transparent blur-3xl opacity-50"></div>
              <div className={`relative bg-gradient-to-br ${card.color} rounded-3xl p-10 text-white shadow-2xl overflow-hidden`}>
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32"></div>
                <div className="absolute bottom-0 left-0 w-48 h-48 bg-black/10 rounded-full -ml-24 -mb-24"></div>
                
                <div className="relative z-10">
                  <div className="mb-8">
                    <p className="text-xs opacity-75 mb-3 tracking-widest uppercase font-bold">
                      {card.type.replace("-", " ")}
                    </p>
                    <h2 className="text-3xl md:text-4xl font-light tracking-wide">{card.name}</h2>
                  </div>
                  
                  <p className="text-2xl tracking-[0.25em] mb-8 font-light">{card.number}</p>
                  
                  <div className="grid grid-cols-2 gap-8 pt-6 border-t border-white/20">
                    <div>
                      <p className="text-[10px] opacity-75 mb-2 tracking-wider uppercase font-bold">Issued</p>
                      <p className="text-lg font-light">
                        {new Date(card.issueDate).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric',
                          year: 'numeric' 
                        })}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] opacity-75 mb-2 tracking-wider uppercase font-bold">Expires</p>
                      <p className="text-lg font-light">
                        {new Date(card.expiryDate).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric',
                          year: 'numeric' 
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Details Section */}
      <div className="max-w-5xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Basic Information */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/90 dark:bg-slate-900/90 border border-cyan-200/40 dark:border-cyan-900/20 rounded-2xl p-8 shadow-lg shadow-blue-100/30 dark:shadow-cyan-900/20 backdrop-blur-sm"
          >
            <h3 className="text-slate-800 dark:text-white mb-8 flex items-center gap-3 text-xl font-light tracking-wide">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 dark:from-cyan-900/20 dark:to-blue-900/20 rounded-xl flex items-center justify-center">
                <Info className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
              </div>
              <span>Basic Information</span>
            </h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4 pb-6 border-b border-cyan-200/30 dark:border-cyan-900/20">
                <Hash className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-1" />
                <div className="flex-1">
                  <p className="text-[10px] text-slate-500 dark:text-slate-500 tracking-[0.2em] uppercase mb-2 font-bold">Identification Number</p>
                  <p className="text-slate-800 dark:text-white text-lg font-light tracking-wide">{card.number}</p>
                </div>
              </div>
              <div className="flex items-start gap-4 pb-6 border-b border-cyan-200/30 dark:border-cyan-900/20">
                <Building2 className="w-5 h-5 text-cyan-600 dark:text-cyan-400 mt-1" />
                <div className="flex-1">
                  <p className="text-[10px] text-slate-500 dark:text-slate-500 tracking-[0.2em] uppercase mb-2 font-bold">Issuing Authority</p>
                  <p className="text-slate-800 dark:text-white text-lg font-light">{card.issuingAuthority}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Calendar className="w-5 h-5 text-green-600 dark:text-green-400 mt-1" />
                <div className="flex-1">
                  <p className="text-[10px] text-slate-500 dark:text-slate-500 tracking-[0.2em] uppercase mb-2 font-bold">Valid Period</p>
                  <p className="text-slate-800 dark:text-white font-light">
                    {new Date(card.issueDate).toLocaleDateString('en-US', { 
                      month: 'long', 
                      day: 'numeric',
                      year: 'numeric' 
                    })} - {new Date(card.expiryDate).toLocaleDateString('en-US', { 
                      month: 'long', 
                      day: 'numeric',
                      year: 'numeric' 
                    })}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Additional Information */}
          {Object.keys(card.additionalInfo).length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white/90 dark:bg-slate-900/90 border border-cyan-200/40 dark:border-cyan-900/20 rounded-2xl p-8 shadow-lg shadow-blue-100/30 dark:shadow-cyan-900/20 backdrop-blur-sm"
            >
              <h3 className="text-stone-900 dark:text-white mb-8 text-xl font-light tracking-wide">Additional Details</h3>
              <div className="space-y-6">
                {Object.entries(card.additionalInfo).map(([key, value]) => (
                  <div key={key} className="flex justify-between items-center pb-6 border-b border-stone-100 dark:border-white/5 last:border-0 last:pb-0">
                    <span className="text-[10px] text-stone-400 dark:text-gray-600 tracking-[0.2em] uppercase font-bold">
                      {key.replace(/([A-Z])/g, " $1").trim()}
                    </span>
                    <span className="text-stone-900 dark:text-white font-light text-lg">{value}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid md:grid-cols-3 gap-4 mt-12"
        >
          <button
            onClick={() => navigate(`/qr/${card.id}`)}
            className="bg-gradient-to-br from-green-500 to-cyan-600 hover:from-green-600 hover:to-cyan-700 text-white py-5 px-6 rounded-xl flex items-center justify-center gap-3 transition-all duration-300 shadow-lg shadow-green-500/30 hover:shadow-xl hover:shadow-green-600/40"
          >
            <QrCode className="w-5 h-5" />
            <span className="tracking-[0.2em] text-[10px] font-bold uppercase">Generate QR</span>
          </button>

          <button className="bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 dark:hover:bg-slate-600 text-white py-5 px-6 rounded-xl flex items-center justify-center gap-3 transition-all duration-300 border border-cyan-200/20 dark:border-cyan-900/20 hover:border-cyan-400/40">
            <Share2 className="w-5 h-5 text-cyan-400" />
            <span className="tracking-[0.2em] text-[10px] font-bold uppercase">Share</span>
          </button>

          <button className="bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 dark:hover:bg-slate-600 text-white py-5 px-6 rounded-xl flex items-center justify-center gap-3 transition-all duration-300 border border-cyan-200/20 dark:border-cyan-900/20 hover:border-cyan-400/40">
            <Download className="w-5 h-5 text-blue-400" />
            <span className="tracking-[0.2em] text-[10px] font-bold uppercase">Export</span>
          </button>
        </motion.div>
      </div>
    </div>
  );
}