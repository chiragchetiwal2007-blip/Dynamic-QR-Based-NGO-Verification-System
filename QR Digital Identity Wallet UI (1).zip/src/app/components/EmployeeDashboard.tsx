import { Link } from "react-router";
import { identityCards } from "../data/identityData";
import { CreditCard, ChevronRight, ArrowLeft, Camera, QrCode, Shield, Clock } from "lucide-react";
import { CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

export function EmployeeDashboard() {
  return (
    <div className="bg-transparent min-h-screen pb-20 md:pb-8 transition-colors duration-500">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-blue-100/40 dark:from-blue-950/20 to-transparent border-b border-blue-200/30 dark:border-blue-900/20">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <Link to="/" className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors mb-8 group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] tracking-[0.2em] font-bold uppercase">Back to Dashboard</span>
          </Link>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/30">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl text-slate-800 dark:text-white mb-1 tracking-tight font-light">
                  Employee Portal
                </h1>
                <p className="text-slate-600 dark:text-slate-300 text-lg tracking-wide">Standard Access Level</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid md:grid-cols-2 gap-4 mb-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Link
              to="/qr/id-001"
              className="block group bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30 border border-cyan-200/50 dark:border-cyan-900/20 rounded-2xl p-6 hover:border-cyan-400/60 dark:hover:border-cyan-600/40 transition-all duration-300 shadow-lg shadow-cyan-100/30 dark:shadow-cyan-900/20 hover:shadow-xl hover:shadow-cyan-200/40 dark:hover:shadow-cyan-800/30"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                    <QrCode className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl text-slate-800 dark:text-white font-medium tracking-wide mb-1">Generate QR Code</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">Share your credentials</p>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-cyan-600 dark:text-cyan-400 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="block bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 border border-green-200/50 dark:border-green-900/20 rounded-2xl p-6 shadow-lg shadow-green-100/30 dark:shadow-green-900/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                    <CheckCircle2 className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl text-slate-800 dark:text-white font-medium tracking-wide mb-1">Verification Status</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">All credentials verified</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-800/50 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs text-green-700 dark:text-green-400 tracking-wider uppercase font-bold">Active</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* My Credentials Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-cyan-300/30 dark:via-cyan-900/20 to-transparent"></div>
            <h2 className="text-xs text-slate-500 dark:text-slate-400 tracking-[0.3em] uppercase font-bold">My Credentials</h2>
            <div className="h-px flex-1 bg-gradient-to-l from-transparent via-cyan-300/30 dark:via-cyan-900/20 to-transparent"></div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {identityCards.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
              >
                <Link to={`/card/${card.id}`}>
                  <div className="group relative bg-white/90 dark:bg-slate-900/90 border border-cyan-200/40 dark:border-cyan-900/20 rounded-2xl p-6 overflow-hidden hover:border-cyan-400/60 dark:hover:border-cyan-600/40 transition-all duration-300 active:scale-[0.98] shadow-lg shadow-blue-100/30 dark:shadow-cyan-900/20 hover:shadow-xl hover:shadow-cyan-200/40 dark:hover:shadow-cyan-800/30 backdrop-blur-sm">
                    <div className="relative z-10">
                      <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 bg-gradient-to-br ${card.color} rounded-xl flex items-center justify-center shadow-lg`}>
                            <CreditCard className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="text-lg text-slate-800 dark:text-white font-medium tracking-wide">{card.name}</h3>
                            <p className="text-[10px] text-slate-600 dark:text-slate-400 tracking-[0.2em] uppercase mt-0.5">
                              {card.type.replace("-", " ")}
                            </p>
                          </div>
                        </div>
                        <div className="w-8 h-8 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 dark:from-cyan-900/20 dark:to-blue-900/20 rounded-full flex items-center justify-center">
                          <ChevronRight className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t border-cyan-200/30 dark:border-cyan-900/20">
                        <div className="space-y-1">
                          <p className="text-[8px] text-slate-500 dark:text-slate-500 tracking-widest uppercase font-bold">Identifier</p>
                          <p className="text-xs text-slate-700 dark:text-slate-300 font-mono tracking-wider">{card.number}</p>
                        </div>
                        <div className="text-right space-y-1">
                          <p className="text-[8px] text-slate-500 dark:text-slate-500 tracking-widest uppercase font-bold">Valid Thru</p>
                          <p className="text-xs text-cyan-600 dark:text-cyan-400 font-mono">
                            {new Date(card.expiryDate).toLocaleDateString('en-US', { 
                              month: '2-digit', 
                              year: '2-digit' 
                            })}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Add Card Button */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="w-full py-6 border border-dashed border-cyan-300/50 dark:border-cyan-800/40 rounded-2xl text-slate-500 dark:text-slate-400 hover:border-green-400/60 dark:hover:border-green-600/40 hover:text-green-600 dark:hover:text-green-400 transition-all duration-300 flex items-center justify-center gap-3 bg-gradient-to-br from-cyan-50/30 to-green-50/30 dark:from-cyan-950/10 dark:to-green-950/10 group backdrop-blur-sm"
        >
          <div className="w-8 h-8 rounded-full border border-cyan-300/50 dark:border-cyan-800/40 flex items-center justify-center group-hover:border-green-500 dark:group-hover:border-green-500 transition-colors bg-white/50 dark:bg-slate-900/50">
            <span className="text-xl font-light">+</span>
          </div>
          <span className="text-[10px] tracking-[0.3em] uppercase font-bold">Request New Credential</span>
        </motion.button>
      </div>
    </div>
  );
}