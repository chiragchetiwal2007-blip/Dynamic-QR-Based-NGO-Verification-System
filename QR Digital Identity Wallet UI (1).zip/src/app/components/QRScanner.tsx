import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { 
  ArrowLeft, 
  Camera, 
  CheckCircle2, 
  XCircle, 
  Shield, 
  AlertTriangle,
  ScanLine,
  Sparkles,
  Clock,
  User
} from "lucide-react";

type ScanState = "ready" | "scanning" | "verified" | "not-verified";

export function QRScanner() {
  const [scanState, setScanState] = useState<ScanState>("ready");
  const [scannedData, setScannedData] = useState<any>(null);
  const [scanProgress, setScanProgress] = useState(0);

  // Simulate scanning process
  const handleStartScan = () => {
    setScanState("scanning");
    setScanProgress(0);
    
    // Simulate scanning progress
    const progressInterval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 10;
      });
    }, 150);

    // Simulate scan completion
    setTimeout(() => {
      clearInterval(progressInterval);
      
      // Randomly determine if verified or not (70% chance of verified)
      const isVerified = Math.random() > 0.3;
      
      setScannedData({
        id: "id-001",
        name: "UN Humanitarian ID",
        number: "UN-2024-NGO-7823",
        issueDate: "2024-01-15",
        expiryDate: "2025-01-15",
        holder: "NGO Professional",
        organization: "United Nations",
        verified: isVerified,
        scanTime: new Date().toISOString(),
      });
      
      setScanState(isVerified ? "verified" : "not-verified");
    }, 2000);
  };

  const handleReset = () => {
    setScanState("ready");
    setScannedData(null);
    setScanProgress(0);
  };

  return (
    <div className="bg-transparent min-h-screen pb-20 md:pb-8 transition-colors duration-500">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-cyan-100/40 dark:from-cyan-950/20 to-transparent border-b border-cyan-200/30 dark:border-cyan-900/20">
        <div className="max-w-5xl mx-auto px-6 py-12">
          <Link to="/" className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors mb-8 group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] tracking-[0.2em] font-bold uppercase">Back to Dashboard</span>
          </Link>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl md:text-5xl text-slate-800 dark:text-white mb-4 tracking-tight font-light">
              Credential Scanner
            </h1>
            <p className="text-slate-600 dark:text-slate-300 text-lg tracking-wide">
              Scan QR codes to verify NGO credentials
            </p>
          </motion.div>
        </div>
      </div>

      {/* Scanner Section */}
      <div className="max-w-3xl mx-auto px-6 py-16">
        <AnimatePresence mode="wait">
          {/* Ready State */}
          {scanState === "ready" && (
            <motion.div
              key="ready"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="text-center"
            >
              <div className="relative inline-block mb-12">
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-blue-400/20 blur-3xl opacity-50"></div>
                <div className="relative w-48 h-48 bg-gradient-to-br from-white to-cyan-50 dark:from-slate-800 dark:to-cyan-950/30 rounded-3xl border-4 border-cyan-200/50 dark:border-cyan-900/30 flex items-center justify-center shadow-2xl">
                  <Camera className="w-24 h-24 text-cyan-600 dark:text-cyan-400" />
                  <div className="absolute top-4 right-4 w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
                </div>
              </div>

              <h2 className="text-2xl text-slate-800 dark:text-white mb-4 font-light">
                Ready to Scan
              </h2>
              <p className="text-slate-600 dark:text-slate-400 mb-12 max-w-md mx-auto">
                Position a QR code within the camera frame to verify NGO credentials
              </p>

              <button
                onClick={handleStartScan}
                className="bg-gradient-to-r from-blue-500 via-cyan-500 to-green-500 text-white px-12 py-5 rounded-2xl flex items-center justify-center gap-3 mx-auto transition-all duration-300 shadow-lg shadow-cyan-500/30 hover:shadow-xl hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98]"
              >
                <Camera className="w-6 h-6" />
                <span className="text-sm tracking-[0.2em] uppercase font-bold">Start Scanning</span>
              </button>

              <div className="mt-16 grid grid-cols-3 gap-6 max-w-2xl mx-auto">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Shield className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">Secure Verification</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Sparkles className="w-6 h-6 text-green-600 dark:text-green-400" />
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">Instant Results</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-cyan-100 dark:bg-cyan-900/30 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Clock className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">Real-Time Sync</p>
                </div>
              </div>
            </motion.div>
          )}

          {/* Scanning State */}
          {scanState === "scanning" && (
            <motion.div
              key="scanning"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center"
            >
              <div className="relative inline-block mb-8">
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/30 to-blue-500/30 blur-3xl animate-pulse"></div>
                <div className="relative w-64 h-64 bg-gradient-to-br from-white to-cyan-50 dark:from-slate-800 dark:to-cyan-950/30 rounded-3xl border-4 border-cyan-400 dark:border-cyan-500 flex items-center justify-center shadow-2xl overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <motion.div
                      animate={{ y: ["-100%", "100%"] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      className="w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-70"
                    >
                      <ScanLine className="w-full h-full text-cyan-500" />
                    </motion.div>
                  </div>
                  <Camera className="w-20 h-20 text-cyan-600/30 dark:text-cyan-400/30" />
                </div>
              </div>

              <motion.h2 
                className="text-2xl text-slate-800 dark:text-white mb-4 font-light"
                animate={{ opacity: [1, 0.5, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                Scanning QR Code...
              </motion.h2>
              
              <div className="max-w-md mx-auto mb-8">
                <div className="h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-blue-500 via-cyan-500 to-green-500"
                    initial={{ width: "0%" }}
                    animate={{ width: `${scanProgress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-3">{scanProgress}% Complete</p>
              </div>

              <div className="flex items-center justify-center gap-2 text-cyan-600 dark:text-cyan-400">
                <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
                <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></div>
                <div className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
              </div>
            </motion.div>
          )}

          {/* Verified State */}
          {scanState === "verified" && scannedData && (
            <motion.div
              key="verified"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="relative inline-block mb-8"
              >
                <div className="absolute inset-0 bg-green-400/30 blur-3xl animate-pulse"></div>
                <div className="relative w-32 h-32 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-2xl">
                  <CheckCircle2 className="w-20 h-20 text-white" />
                </div>
              </motion.div>

              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-3xl text-green-600 dark:text-green-400 mb-2 font-medium tracking-wide"
              >
                VERIFIED
              </motion.h2>
              
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-slate-600 dark:text-slate-400 mb-8"
              >
                Credential authenticated successfully
              </motion.p>

              {/* Credential Details */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-white/90 dark:bg-slate-900/90 border border-green-200/50 dark:border-green-900/20 rounded-2xl p-8 max-w-2xl mx-auto mb-8 shadow-lg shadow-green-100/30 dark:shadow-green-900/20 backdrop-blur-sm"
              >
                <div className="flex items-center gap-4 mb-6 pb-6 border-b border-green-200/30 dark:border-green-900/20">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-700 rounded-xl flex items-center justify-center shadow-lg">
                    <Shield className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-left flex-1">
                    <h3 className="text-xl text-slate-800 dark:text-white font-medium">{scannedData.name}</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400 font-mono">{scannedData.number}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6 text-left">
                  <div>
                    <p className="text-[10px] text-slate-500 dark:text-slate-500 tracking-[0.2em] uppercase font-bold mb-2">Holder</p>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                      <p className="text-slate-800 dark:text-white font-light">{scannedData.holder}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 dark:text-slate-500 tracking-[0.2em] uppercase font-bold mb-2">Organization</p>
                    <p className="text-slate-800 dark:text-white font-light">{scannedData.organization}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 dark:text-slate-500 tracking-[0.2em] uppercase font-bold mb-2">Issue Date</p>
                    <p className="text-slate-800 dark:text-white font-light">
                      {new Date(scannedData.issueDate).toLocaleDateString('en-US', { 
                        month: 'long', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 dark:text-slate-500 tracking-[0.2em] uppercase font-bold mb-2">Expiry Date</p>
                    <p className="text-green-600 dark:text-green-400 font-light">
                      {new Date(scannedData.expiryDate).toLocaleDateString('en-US', { 
                        month: 'long', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}
                    </p>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-green-200/30 dark:border-green-900/20 flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
                  <p className="text-sm text-green-600 dark:text-green-400 font-medium">
                    Verified at {new Date(scannedData.scanTime).toLocaleTimeString()}
                  </p>
                </div>
              </motion.div>

              <button
                onClick={handleReset}
                className="bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 dark:hover:bg-slate-600 text-white px-12 py-5 rounded-2xl flex items-center justify-center gap-3 mx-auto transition-all duration-300 border border-cyan-200/20 dark:border-cyan-900/20 hover:border-cyan-400/40"
              >
                <Camera className="w-5 h-5" />
                <span className="text-sm tracking-[0.2em] uppercase font-bold">Scan Another</span>
              </button>
            </motion.div>
          )}

          {/* Not Verified State */}
          {scanState === "not-verified" && scannedData && (
            <motion.div
              key="not-verified"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="relative inline-block mb-8"
              >
                <div className="absolute inset-0 bg-red-400/30 blur-3xl animate-pulse"></div>
                <div className="relative w-32 h-32 bg-gradient-to-br from-red-400 to-red-600 rounded-full flex items-center justify-center shadow-2xl">
                  <XCircle className="w-20 h-20 text-white" />
                </div>
              </motion.div>

              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-3xl text-red-600 dark:text-red-400 mb-2 font-medium tracking-wide"
              >
                NOT VERIFIED
              </motion.h2>
              
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-slate-600 dark:text-slate-400 mb-8"
              >
                This credential could not be authenticated
              </motion.p>

              {/* Warning Details */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-white/90 dark:bg-slate-900/90 border border-red-200/50 dark:border-red-900/20 rounded-2xl p-8 max-w-2xl mx-auto mb-8 shadow-lg shadow-red-100/30 dark:shadow-red-900/20 backdrop-blur-sm"
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center">
                    <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-400" />
                  </div>
                  <div className="text-left flex-1">
                    <h3 className="text-xl text-slate-800 dark:text-white font-medium">Verification Failed</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">Credential authenticity could not be confirmed</p>
                  </div>
                </div>

                <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/30 rounded-xl p-6 text-left">
                  <p className="text-sm text-red-700 dark:text-red-400 font-medium mb-3">Possible reasons:</p>
                  <ul className="space-y-2 text-sm text-slate-700 dark:text-slate-300">
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Credential has expired or been revoked</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>QR code may be damaged or counterfeit</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Issuing authority database unavailable</span>
                    </li>
                  </ul>
                </div>

                <div className="mt-6 pt-6 border-t border-red-200/30 dark:border-red-900/20 flex items-center justify-center gap-2">
                  <XCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
                  <p className="text-sm text-red-600 dark:text-red-400 font-medium">
                    Scanned at {new Date(scannedData.scanTime).toLocaleTimeString()}
                  </p>
                </div>
              </motion.div>

              <button
                onClick={handleReset}
                className="bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 dark:hover:bg-slate-600 text-white px-12 py-5 rounded-2xl flex items-center justify-center gap-3 mx-auto transition-all duration-300 border border-cyan-200/20 dark:border-cyan-900/20 hover:border-cyan-400/40"
              >
                <Camera className="w-5 h-5" />
                <span className="text-sm tracking-[0.2em] uppercase font-bold">Try Again</span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
