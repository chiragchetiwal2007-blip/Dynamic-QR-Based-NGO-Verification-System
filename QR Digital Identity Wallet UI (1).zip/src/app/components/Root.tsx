import { Outlet, Link, useLocation, useNavigate } from "react-router";
import { Home, QrCode, Settings, Shield, Sun, Moon } from "lucide-react";
import { useEffect, useState } from "react";

export function Root() {
  const location = useLocation();
  const navigate = useNavigate();
  const [theme, setTheme] = useState(localStorage.getItem("theme") || "dark");

  // Handle theme changes
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  // Check authentication on component mount
  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    if (!isLoggedIn) {
      navigate("/login");
    }
  }, [navigate]);

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-green-50 dark:from-slate-950 dark:via-blue-950 dark:to-emerald-950 transition-colors duration-500">
      {/* Top Navigation Bar */}
      <header className="border-b border-blue-200/50 dark:border-cyan-900/30 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md sticky top-0 z-50 shadow-sm shadow-blue-100/50 dark:shadow-cyan-900/20">
        <div className="max-w-7xl mx-auto px-5 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-blue-500 via-cyan-500 to-green-500 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/30">
                <Shield className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <h1 className="text-base sm:text-xl bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent tracking-[0.2em] font-light uppercase">NGO Vault</h1>
                <p className="hidden sm:block text-[8px] text-cyan-600 dark:text-cyan-400 tracking-[0.3em] uppercase">Built for NGOs. Backed by trust.</p>
              </div>
            </div>
            
            <nav className="hidden md:flex items-center gap-8">
              <Link
                to="/"
                className={`text-xs tracking-[0.2em] transition-colors ${
                  isActive("/") && !location.pathname.includes("qr") && !location.pathname.includes("card")
                    ? "text-blue-600 dark:text-cyan-400"
                    : "text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-cyan-400"
                }`}
              >
                DASHBOARD
              </Link>
              <Link
                to="/scanner"
                className={`text-xs tracking-[0.2em] transition-colors ${
                  location.pathname.includes("scanner")
                    ? "text-green-600 dark:text-green-400"
                    : "text-slate-500 dark:text-slate-400 hover:text-green-600 dark:hover:text-green-400"
                }`}
              >
                SCANNER
              </Link>
              <Link
                to="/qr/id-001"
                className={`text-xs tracking-[0.2em] transition-colors ${
                  location.pathname.includes("qr")
                    ? "text-green-600 dark:text-green-400"
                    : "text-slate-500 dark:text-slate-400 hover:text-green-600 dark:hover:text-green-400"
                }`}
              >
                VERIFICATION
              </Link>
              <Link
                to="/settings"
                className={`text-xs tracking-[0.2em] transition-colors ${
                  isActive("/settings")
                    ? "text-blue-600 dark:text-cyan-400"
                    : "text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-cyan-400"
                }`}
              >
                SETTINGS
              </Link>
            </nav>

            {/* Theme Toggle Button - Top Right */}
            <button
              onClick={toggleTheme}
              className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg border-2 border-cyan-200/50 dark:border-cyan-500/30 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/50 dark:to-cyan-950/50 flex items-center justify-center hover:from-blue-100 hover:to-cyan-100 dark:hover:from-blue-900/60 dark:hover:to-cyan-900/60 hover:border-cyan-400/50 dark:hover:border-cyan-400/50 transition-all duration-300 group shadow-md shadow-blue-200/30 dark:shadow-cyan-900/30"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? (
                <Sun className="w-5 h-5 sm:w-6 sm:h-6 text-cyan-500 group-hover:rotate-180 transition-transform duration-500" />
              ) : (
                <Moon className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600 group-hover:-rotate-180 transition-transform duration-500" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="min-h-[calc(100vh-65px)]">
        <Outlet />
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 border-t border-blue-200/50 dark:border-cyan-900/30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl z-50 transition-colors duration-500 shadow-lg shadow-blue-100/50 dark:shadow-cyan-900/20">
        <div className="flex items-center justify-around px-2 py-4">
          <Link
            to="/"
            className={`flex flex-col items-center gap-1.5 px-4 transition-all duration-300 ${
              isActive("/") && !location.pathname.includes("qr") && !location.pathname.includes("card")
                ? "text-blue-600 dark:text-cyan-400 scale-110"
                : "text-slate-400 dark:text-slate-500"
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[9px] tracking-[0.15em] font-bold uppercase">Home</span>
          </Link>

          <Link
            to="/qr/id-001"
            className={`flex flex-col items-center gap-1.5 px-4 transition-all duration-300 ${
              location.pathname.includes("qr")
                ? "text-green-600 dark:text-green-400 scale-110"
                : "text-slate-400 dark:text-slate-500"
            }`}
          >
            <div className="relative">
              <QrCode className="w-5 h-5" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full border border-white dark:border-slate-900"></div>
            </div>
            <span className="text-[9px] tracking-[0.15em] font-bold uppercase">Verify</span>
          </Link>

          <Link
            to="/settings"
            className={`flex flex-col items-center gap-1.5 px-4 transition-all duration-300 ${
              isActive("/settings")
                ? "text-blue-600 dark:text-cyan-400 scale-110"
                : "text-slate-400 dark:text-slate-500"
            }`}
          >
            <Settings className="w-5 h-5" />
            <span className="text-[9px] tracking-[0.15em] font-bold uppercase">Prefs</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}