import { useState } from "react";
import { useNavigate } from "react-router";
import { Shield, Lock, User, Eye, EyeOff, Fingerprint, AlertCircle, CheckCircle2, Sun, Moon } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Login() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [isSignupMode, setIsSignupMode] = useState(false);
  
  // Theme state
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      return document.documentElement.classList.contains('dark');
    }
    return false;
  });

  const toggleTheme = () => {
    const newTheme = !isDark;
    setIsDark(newTheme);
    if (newTheme) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess(false);
    setIsLoading(true);
    
    // UI Prototype Logic: Simulating a secure verification process
    // In a real app, this would be a network call
    setTimeout(() => {
      setIsLoading(false);
      
      // Mock validation logic for prototype demonstration
      if (email === "demo@ngo.org" && password === "password123") {
        setSuccess(true);
        // Simulate storage for prototype persistence
        localStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("user", JSON.stringify({ 
          id: "mock-user-123", 
          email: "demo@ngo.org", 
          name: "NGO Professional" 
        }));
        
        // Brief delay to show success state before navigating
        setTimeout(() => {
          navigate("/");
        }, 1500);
      } else if (email === "" || password === "") {
        setError("Please enter your credentials to access the vault.");
      } else {
        setError("Invalid credentials. Please verify your email and password.");
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-green-50 dark:from-slate-950 dark:via-blue-950 dark:to-emerald-950 flex items-center justify-center relative overflow-hidden transition-colors duration-500">
      {/* Theme Toggle Button */}
      <motion.button
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5 }}
        onClick={toggleTheme}
        className="fixed top-6 right-6 z-50 w-14 h-14 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-cyan-200/50 dark:border-cyan-900/30 rounded-2xl flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-300 group"
        aria-label="Toggle theme"
      >
        <AnimatePresence mode="wait">
          {isDark ? (
            <motion.div
              key="sun"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Sun className="w-6 h-6 text-amber-500 group-hover:text-amber-600 transition-colors" />
            </motion.div>
          ) : (
            <motion.div
              key="moon"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Moon className="w-6 h-6 text-blue-600 group-hover:text-blue-700 transition-colors" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Background Image Overlay */}
      <div className="absolute inset-0 z-0 opacity-10 dark:opacity-30 grayscale contrast-125">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1671722294182-ed01cbe66bd1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwZGFyayUyMG9mZmljZSUyMGxhbmRzY2FwZSUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NzE0ODUxNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Professional Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/80 via-cyan-50/80 to-green-50/80 dark:from-slate-950/90 dark:via-blue-950/90 dark:to-emerald-950/90 backdrop-blur-sm"></div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500/30 dark:via-cyan-500/50 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-green-500/30 dark:via-green-500/50 to-transparent"></div>

      {/* Mobile-First Container */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="w-full h-full sm:h-auto sm:max-w-md z-10 flex flex-col"
      >
        <div className="flex-1 sm:flex-none bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl border-x-0 sm:border border-cyan-200/50 dark:border-cyan-900/30 sm:rounded-[2.5rem] p-6 sm:p-10 shadow-2xl relative overflow-hidden group flex flex-col justify-center">
          {/* Subtle reflection effect */}
          <div className="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] bg-gradient-to-br from-cyan-400/5 via-transparent to-green-400/5 rotate-12 pointer-events-none group-hover:translate-x-10 transition-transform duration-1000"></div>

          <div className="max-w-sm mx-auto w-full space-y-8 sm:space-y-10">
            {/* Logo Section */}
            <div className="text-center">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
                className="inline-block mb-6"
              >
                <div className="relative group/logo">
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/30 to-green-500/30 blur-3xl opacity-50"></div>
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 via-cyan-500 to-green-500 rounded-3xl flex items-center justify-center relative border border-cyan-400/30 shadow-2xl">
                    <Shield className="w-10 h-10 text-white" />
                  </div>
                </div>
              </motion.div>
              
              <h1 className="text-4xl bg-gradient-to-r from-blue-600 via-cyan-600 to-green-600 bg-clip-text text-transparent font-light tracking-[0.25em] uppercase mb-3">
                NGO Vault
              </h1>
              <div className="flex items-center justify-center gap-2">
                <div className="h-[1px] w-10 bg-gradient-to-r from-transparent to-cyan-300/50 dark:to-cyan-900/50"></div>
                <p className="text-[10px] text-slate-600 dark:text-slate-400 tracking-[0.3em] uppercase whitespace-nowrap">
                  Built for NGOs. Backed by trust.
                </p>
                <div className="h-[1px] w-10 bg-gradient-to-l from-transparent to-cyan-300/50 dark:to-cyan-900/50"></div>
              </div>
            </div>

            {/* Status Messages */}
            <AnimatePresence mode="wait">
              {error && (
                <motion.div
                  key="error"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="p-4 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-start gap-3"
                >
                  <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-700 dark:text-red-400 leading-relaxed font-medium">{error}</p>
                </motion.div>
              )}
              {success && (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="p-4 bg-green-500/10 border border-green-500/30 rounded-2xl flex items-start gap-3"
                >
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-green-700 dark:text-green-400 leading-relaxed font-medium">Access granted. Decrypting vault...</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Form Section */}
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] text-cyan-600 dark:text-cyan-400 tracking-[0.2em] uppercase font-bold ml-4">
                  Work Email
                </label>
                <div className="relative group">
                  <div className="absolute left-5 top-1/2 -translate-y-1/2 text-cyan-500/50 dark:text-cyan-900/60 group-focus-within:text-cyan-600 dark:group-focus-within:text-cyan-400 transition-colors">
                    <User className="w-5 h-5" />
                  </div>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@organization.org"
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-cyan-200/50 dark:border-cyan-900/20 rounded-2xl py-5 pl-14 pr-6 text-slate-800 dark:text-white text-lg placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-400/50 focus:bg-white dark:focus:bg-slate-900 transition-all tracking-wide shadow-inner dark:shadow-none"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] text-cyan-600 dark:text-cyan-400 tracking-[0.2em] uppercase font-bold ml-4">
                  Password
                </label>
                <div className="relative group">
                  <div className="absolute left-5 top-1/2 -translate-y-1/2 text-cyan-500/50 dark:text-cyan-900/60 group-focus-within:text-cyan-600 dark:group-focus-within:text-cyan-400 transition-colors">
                    <Lock className="w-5 h-5" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter Password"
                    className="w-full bg-white/70 dark:bg-slate-900/70 border border-cyan-200/50 dark:border-cyan-900/20 rounded-2xl py-5 pl-14 pr-14 text-slate-800 dark:text-white text-lg placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-400/50 focus:bg-white dark:focus:bg-slate-900 transition-all tracking-wide shadow-inner dark:shadow-none"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors p-2"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between px-2">
                <label className="flex items-center gap-3 cursor-pointer group">
                  <div className={`w-6 h-6 rounded-lg border border-cyan-300/50 dark:border-cyan-900/40 flex items-center justify-center transition-all ${rememberMe ? 'bg-gradient-to-br from-cyan-500 to-green-500 border-cyan-500' : 'bg-transparent'}`}>
                    <input 
                      type="checkbox" 
                      className="hidden" 
                      checked={rememberMe}
                      onChange={() => setRememberMe(!rememberMe)}
                    />
                    {rememberMe && <div className="w-2.5 h-2.5 bg-white rounded-sm"></div>}
                  </div>
                  <span className="text-xs text-slate-600 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-300 transition-colors tracking-wide">Remember Me</span>
                </label>
                <button type="button" className="text-xs text-cyan-600 dark:text-cyan-400 hover:text-green-600 dark:hover:text-green-400 tracking-wide font-medium">
                  Support
                </button>
              </div>

              <button
                type="submit"
                disabled={isLoading || success}
                className={`w-full text-white py-5 rounded-2xl flex items-center justify-center gap-3 transition-all duration-300 shadow-lg hover:scale-[1.01] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed group ${success ? 'bg-green-500' : 'bg-gradient-to-r from-blue-500 via-cyan-500 to-green-500 shadow-cyan-500/30'}`}
              >
                {isLoading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : success ? (
                  <>
                    <span className="text-sm tracking-[0.3em] uppercase font-bold">Authorized</span>
                    <CheckCircle2 className="w-5 h-5" />
                  </>
                ) : (
                  <>
                    <span className="text-sm tracking-[0.3em] uppercase font-bold">
                      {isSignupMode ? "Initialize" : "Secure Login"}
                    </span>
                    <Lock className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                  </>
                )}
              </button>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsSignupMode(!isSignupMode);
                    setError("");
                    setSuccess(false);
                  }}
                  className="text-xs text-slate-500 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors tracking-widest uppercase font-bold"
                >
                  {isSignupMode ? "Back to Login" : "Request Access Token"}
                </button>
              </div>
            </form>

            {/* Biometric Placeholder */}
            <div className="pt-8 border-t border-cyan-200/30 dark:border-cyan-900/20 text-center">
              <button 
                type="button"
                onClick={() => {
                  setIsLoading(true);
                  setTimeout(() => {
                    setIsLoading(false);
                    setError("Biometric verification failed. Please use password.");
                  }, 1000);
                }}
                className="inline-flex items-center gap-3 text-slate-500 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors group"
              >
                <Fingerprint className="w-7 h-7 group-hover:scale-110 transition-transform" />
                <span className="text-xs tracking-widest uppercase font-light">Face ID / Touch ID</span>
              </button>
            </div>
          </div>
        </div>

        {/* Support Section */}
        <div className="py-8 sm:py-10 text-center space-y-4">
          <p className="text-slate-500 dark:text-slate-500 text-[10px] tracking-[0.3em] uppercase font-medium">
            Secured by Vault Protocol v2.4
          </p>
          <div className="flex justify-center gap-6 opacity-40">
            <Shield className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
          </div>
        </div>
      </motion.div>
    </div>
  );
}