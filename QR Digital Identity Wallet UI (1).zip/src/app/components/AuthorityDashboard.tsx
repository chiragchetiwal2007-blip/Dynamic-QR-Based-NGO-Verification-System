import { Link } from "react-router";
import { ArrowLeft, Crown, CheckCircle2, XCircle, AlertTriangle, User, Calendar, Shield, Search, Filter, Camera } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";

// Mock personnel data
const personnelData = [
  {
    id: "emp-001",
    name: "Sarah Johnson",
    role: "Field Coordinator",
    email: "sarah.j@ngo.org",
    credentialId: "UN-2024-NGO-7823",
    verified: true,
    lastVerified: "2024-02-15",
    department: "Operations",
  },
  {
    id: "emp-002",
    name: "Michael Chen",
    role: "Medical Officer",
    email: "m.chen@ngo.org",
    credentialId: "WHO-2024-MED-4521",
    verified: true,
    lastVerified: "2024-02-18",
    department: "Healthcare",
  },
  {
    id: "emp-003",
    name: "Aisha Patel",
    role: "Logistics Manager",
    email: "aisha.p@ngo.org",
    credentialId: "UN-2024-LOG-9834",
    verified: false,
    lastVerified: "2024-01-10",
    department: "Supply Chain",
  },
  {
    id: "emp-004",
    name: "James Rodriguez",
    role: "Communication Lead",
    email: "j.rodriguez@ngo.org",
    credentialId: "UN-2024-COM-6712",
    verified: true,
    lastVerified: "2024-02-19",
    department: "Communications",
  },
  {
    id: "emp-005",
    name: "Fatima Al-Rashid",
    role: "Finance Director",
    email: "f.alrashid@ngo.org",
    credentialId: "UN-2024-FIN-3345",
    verified: true,
    lastVerified: "2024-02-17",
    department: "Finance",
  },
  {
    id: "emp-006",
    name: "David Okonkwo",
    role: "Project Manager",
    email: "d.okonkwo@ngo.org",
    credentialId: "UN-2024-PRJ-8821",
    verified: false,
    lastVerified: "2024-01-25",
    department: "Programs",
  },
  {
    id: "emp-007",
    name: "Maria Santos",
    role: "HR Specialist",
    email: "m.santos@ngo.org",
    credentialId: "UN-2024-HRM-5567",
    verified: true,
    lastVerified: "2024-02-16",
    department: "Human Resources",
  },
  {
    id: "emp-008",
    name: "Yuki Tanaka",
    role: "Security Advisor",
    email: "y.tanaka@ngo.org",
    credentialId: "UN-2024-SEC-2290",
    verified: false,
    lastVerified: "2024-02-01",
    department: "Security",
  },
];

export function AuthorityDashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "verified" | "not-verified">("all");

  const filteredPersonnel = personnelData.filter((person) => {
    const matchesSearch = 
      person.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      person.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      person.credentialId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      person.department.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = 
      filterStatus === "all" ||
      (filterStatus === "verified" && person.verified) ||
      (filterStatus === "not-verified" && !person.verified);

    return matchesSearch && matchesFilter;
  });

  const stats = {
    total: personnelData.length,
    verified: personnelData.filter(p => p.verified).length,
    notVerified: personnelData.filter(p => !p.verified).length,
  };

  return (
    <div className="bg-transparent min-h-screen pb-20 md:pb-8 transition-colors duration-500">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-green-100/40 dark:from-green-950/20 to-transparent border-b border-green-200/30 dark:border-green-900/20">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <Link to="/" className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:text-green-600 dark:hover:text-green-400 transition-colors mb-8 group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] tracking-[0.2em] font-bold uppercase">Back to Dashboard</span>
          </Link>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg shadow-green-500/30">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-4xl md:text-5xl text-slate-800 dark:text-white tracking-tight font-light">
                    Authority Dashboard
                  </h1>
                  <span className="bg-gradient-to-r from-amber-400 to-amber-600 text-white px-3 py-1 rounded-full text-[8px] tracking-widest uppercase font-bold shadow-lg">
                    Premium
                  </span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 text-lg tracking-wide">Full Access & Management</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Statistics */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Scan Credential Quick Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Link
            to="/scanner"
            className="block group bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30 border-2 border-cyan-200/50 dark:border-cyan-900/30 rounded-2xl p-6 hover:border-cyan-400/60 dark:hover:border-cyan-600/40 transition-all duration-300 shadow-xl shadow-cyan-100/30 dark:shadow-cyan-900/20 hover:shadow-2xl hover:shadow-cyan-200/40 dark:hover:shadow-cyan-800/30 hover:scale-[1.01] active:scale-[0.99]"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-cyan-500/30">
                  <Camera className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl text-slate-800 dark:text-white font-medium tracking-wide mb-1">Scan Credential</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Verify employee identity documents</p>
                </div>
              </div>
              <div className="w-10 h-10 bg-cyan-500/10 dark:bg-cyan-900/30 rounded-xl flex items-center justify-center group-hover:bg-cyan-500/20 dark:group-hover:bg-cyan-900/40 transition-colors">
                <svg className="w-6 h-6 text-cyan-600 dark:text-cyan-400 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 border border-blue-200/50 dark:border-blue-900/20 rounded-2xl p-6 shadow-lg shadow-blue-100/30 dark:shadow-blue-900/20"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-blue-500/10 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
                <User className="w-6 h-6 text-blue-600 dark:text-cyan-400" />
              </div>
            </div>
            <h3 className="text-3xl text-slate-800 dark:text-white mb-1 font-light">{stats.total}</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 tracking-widest uppercase font-bold">Total Personnel</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 border border-green-200/50 dark:border-green-900/20 rounded-2xl p-6 shadow-lg shadow-green-100/30 dark:shadow-green-900/20"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-green-500/10 dark:bg-green-900/30 rounded-xl flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <h3 className="text-3xl text-slate-800 dark:text-white mb-1 font-light">{stats.verified}</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 tracking-widest uppercase font-bold">Verified</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/30 dark:to-orange-950/30 border border-red-200/50 dark:border-red-900/20 rounded-2xl p-6 shadow-lg shadow-red-100/30 dark:shadow-red-900/20"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-red-500/10 dark:bg-red-900/30 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
              </div>
            </div>
            <h3 className="text-3xl text-slate-800 dark:text-white mb-1 font-light">{stats.notVerified}</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 tracking-widest uppercase font-bold">Pending Review</p>
          </motion.div>
        </div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-8 space-y-4"
        >
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="Search by name, email, or credential ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/90 dark:bg-slate-900/90 border border-cyan-200/40 dark:border-cyan-900/20 rounded-xl py-3 pl-12 pr-4 text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-400/50 transition-all shadow-sm"
              />
            </div>

            {/* Filter */}
            <div className="flex gap-2">
              <button
                onClick={() => setFilterStatus("all")}
                className={`px-6 py-3 rounded-xl text-sm font-bold tracking-wider uppercase transition-all ${
                  filterStatus === "all"
                    ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg"
                    : "bg-white/90 dark:bg-slate-900/90 border border-cyan-200/40 dark:border-cyan-900/20 text-slate-600 dark:text-slate-400"
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterStatus("verified")}
                className={`px-6 py-3 rounded-xl text-sm font-bold tracking-wider uppercase transition-all ${
                  filterStatus === "verified"
                    ? "bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg"
                    : "bg-white/90 dark:bg-slate-900/90 border border-green-200/40 dark:border-green-900/20 text-slate-600 dark:text-slate-400"
                }`}
              >
                Verified
              </button>
              <button
                onClick={() => setFilterStatus("not-verified")}
                className={`px-6 py-3 rounded-xl text-sm font-bold tracking-wider uppercase transition-all ${
                  filterStatus === "not-verified"
                    ? "bg-gradient-to-r from-red-500 to-orange-600 text-white shadow-lg"
                    : "bg-white/90 dark:bg-slate-900/90 border border-red-200/40 dark:border-red-900/20 text-slate-600 dark:text-slate-400"
                }`}
              >
                Pending
              </button>
            </div>
          </div>
        </motion.div>

        {/* Personnel List */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-cyan-300/30 dark:via-cyan-900/20 to-transparent"></div>
            <h2 className="text-xs text-slate-500 dark:text-slate-400 tracking-[0.3em] uppercase font-bold">
              Personnel Directory ({filteredPersonnel.length})
            </h2>
            <div className="h-px flex-1 bg-gradient-to-l from-transparent via-cyan-300/30 dark:via-cyan-900/20 to-transparent"></div>
          </div>

          {filteredPersonnel.map((person, index) => (
            <motion.div
              key={person.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 + index * 0.05 }}
              className={`bg-white/90 dark:bg-slate-900/90 border rounded-2xl p-6 shadow-lg backdrop-blur-sm transition-all duration-300 hover:shadow-xl ${
                person.verified
                  ? "border-green-200/40 dark:border-green-900/20 hover:border-green-400/60 dark:hover:border-green-600/40 shadow-green-100/20 dark:shadow-green-900/10 hover:shadow-green-200/30"
                  : "border-red-200/40 dark:border-red-900/20 hover:border-red-400/60 dark:hover:border-red-600/40 shadow-red-100/20 dark:shadow-red-900/10 hover:shadow-red-200/30"
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-4 flex-1">
                  {/* Avatar */}
                  <div className={`w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg ${
                    person.verified
                      ? "bg-gradient-to-br from-green-500 to-emerald-600"
                      : "bg-gradient-to-br from-red-500 to-orange-600"
                  }`}>
                    <User className="w-7 h-7 text-white" />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg text-slate-800 dark:text-white font-medium tracking-wide">{person.name}</h3>
                      {person.verified ? (
                        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-800/50 rounded-lg">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
                          <span className="text-[9px] text-green-700 dark:text-green-400 tracking-wider uppercase font-bold">Verified</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-red-100 dark:bg-red-900/30 border border-red-200 dark:border-red-800/50 rounded-lg">
                          <XCircle className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
                          <span className="text-[9px] text-red-700 dark:text-red-400 tracking-wider uppercase font-bold">Not Verified</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                        <Shield className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                        <span className="font-medium">{person.role}</span>
                        <span className="text-slate-400 dark:text-slate-500">•</span>
                        <span>{person.department}</span>
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs">
                        <span className="text-slate-500 dark:text-slate-500">
                          <span className="font-bold tracking-wider uppercase">Email:</span>{" "}
                          <span className="text-slate-700 dark:text-slate-300">{person.email}</span>
                        </span>
                        <span className="text-slate-500 dark:text-slate-500">
                          <span className="font-bold tracking-wider uppercase">ID:</span>{" "}
                          <span className="text-cyan-600 dark:text-cyan-400 font-mono">{person.credentialId}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Last Verified */}
                <div className="flex items-center gap-3 md:flex-col md:items-end md:justify-center pl-[4.5rem] md:pl-0">
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                    <Calendar className="w-4 h-4" />
                    <div className="text-xs">
                      <p className="font-bold tracking-wider uppercase mb-0.5">Last Check</p>
                      <p className="text-slate-700 dark:text-slate-300">
                        {new Date(person.lastVerified).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                  
                  <button className="px-4 py-2 bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 dark:hover:bg-slate-600 text-white rounded-lg text-xs tracking-wider uppercase font-bold transition-all border border-cyan-200/20 dark:border-cyan-900/20 hover:border-cyan-400/40 whitespace-nowrap">
                    View Details
                  </button>
                </div>
              </div>
            </motion.div>
          ))}

          {filteredPersonnel.length === 0 && (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Search className="w-10 h-10 text-slate-400" />
              </div>
              <p className="text-slate-600 dark:text-slate-400 text-lg mb-2">No personnel found</p>
              <p className="text-slate-500 dark:text-slate-500 text-sm">Try adjusting your search or filter criteria</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}