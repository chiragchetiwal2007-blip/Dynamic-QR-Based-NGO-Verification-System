import { 
  Lock, 
  Bell, 
  Smartphone, 
  Shield, 
  HelpCircle, 
  FileText,
  LogOut,
  ChevronRight,
  User,
  Globe,
  Eye,
  Key
} from "lucide-react";
import { motion } from "motion/react";
import { useNavigate } from "react-router";
import { useState, useEffect } from "react";

export function Settings() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<{ email: string; name?: string } | null>(null);

  useEffect(() => {
    const userStr = localStorage.getItem("user");
    if (userStr) {
      try {
        setUserData(JSON.parse(userStr));
      } catch (error) {
        console.error("Error parsing user data:", error);
      }
    }
  }, []);

  const handleLogout = () => {
    // Clear all authentication data
    localStorage.removeItem("access_token");
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("user");
    localStorage.removeItem("rememberMe");
    
    // Redirect to login
    navigate("/login");
  };

  const settingsGroups = [
    {
      title: "Account Management",
      items: [
        { icon: User, label: "Profile Settings", description: "Personal information & preferences" },
        { icon: Lock, label: "Security Center", description: "Password, 2FA & biometric access" },
        { icon: Bell, label: "Notifications", description: "Alerts, updates & communications" },
      ],
    },
    {
      title: "Privacy & Security",
      items: [
        { icon: Shield, label: "Privacy Controls", description: "Data permissions & visibility" },
        { icon: Eye, label: "Activity Monitor", description: "Access logs & verification history" },
        { icon: Smartphone, label: "Device Management", description: "Trusted devices & sessions" },
        { icon: Key, label: "API Access", description: "Integration keys & webhooks" },
      ],
    },
    {
      title: "Support & Legal",
      items: [
        { icon: HelpCircle, label: "Help Center", description: "Documentation & support resources" },
        { icon: FileText, label: "Legal Information", description: "Terms, privacy & compliance" },
        { icon: Globe, label: "Language & Region", description: "Localization preferences" },
      ],
    },
  ];

  return (
    <div className="bg-transparent min-h-screen pb-20 md:pb-8 transition-colors duration-500">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-blue-100/40 dark:from-blue-950/20 to-transparent border-b border-blue-200/30 dark:border-blue-900/20">
        <div className="max-w-5xl mx-auto px-6 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl text-slate-800 dark:text-white mb-4 tracking-tight font-light">Settings</h1>
            <p className="text-slate-600 dark:text-slate-300 text-lg tracking-wide">Configure your digital identity preferences</p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        {/* Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-cyan-50 dark:from-cyan-950/30 to-blue-50 dark:to-blue-900/10 border border-cyan-200/50 dark:border-cyan-900/20 rounded-2xl p-8 mb-12 relative overflow-hidden shadow-lg shadow-cyan-100/30 dark:shadow-cyan-900/20"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-green-400/10 to-transparent rounded-full -mr-32 -mt-32"></div>
          
          <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 via-cyan-500 to-green-500 rounded-2xl flex items-center justify-center shadow-xl">
              <User className="w-10 h-10 text-white" />
            </div>
            <div className="flex-1 text-center sm:text-left">
              <h2 className="text-2xl text-slate-800 dark:text-white mb-2 font-light tracking-wide">
                {userData?.name || "User"}
              </h2>
              <p className="text-slate-600 dark:text-slate-300 tracking-wide">
                {userData?.email || "user@example.com"}
              </p>
              <div className="flex items-center justify-center sm:justify-start gap-4 mt-3">
                <span className="inline-flex items-center gap-2 px-3 py-1 bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-800/50 rounded-lg text-green-700 dark:text-green-400 text-[10px] tracking-wider font-bold">
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                  VERIFIED
                </span>
                <span className="text-slate-500 dark:text-slate-400 text-xs tracking-wider uppercase font-medium">Member since 2024</span>
              </div>
            </div>
            <button className="w-full sm:w-auto px-6 py-3 bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 dark:hover:bg-slate-600 text-white rounded-xl border border-cyan-200/20 dark:border-cyan-900/20 hover:border-cyan-400/40 transition-all duration-300 tracking-wider text-xs font-bold uppercase">
              Edit Profile
            </button>
          </div>
        </motion.div>

        {/* Settings Groups */}
        <div className="space-y-12">
          {settingsGroups.map((group, groupIndex) => (
            <motion.div
              key={group.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + groupIndex * 0.1 }}
            >
              <h3 className="text-slate-500 dark:text-slate-400 text-[10px] uppercase tracking-[0.3em] font-bold mb-6 flex items-center gap-3">
                <div className="h-px flex-1 bg-gradient-to-r from-cyan-300/30 dark:from-cyan-900/20 to-transparent"></div>
                {group.title}
                <div className="h-px flex-1 bg-gradient-to-l from-cyan-300/30 dark:from-cyan-900/20 to-transparent"></div>
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                {group.items.map((item, index) => (
                  <button
                    key={item.label}
                    className="group bg-white/90 dark:bg-slate-900/90 border border-cyan-200/40 dark:border-cyan-900/20 rounded-2xl p-6 hover:border-cyan-400/60 dark:hover:border-cyan-600/40 transition-all duration-300 text-left shadow-lg shadow-blue-100/20 dark:shadow-cyan-900/20 hover:shadow-xl hover:shadow-cyan-200/30 dark:hover:shadow-cyan-800/30 backdrop-blur-sm"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 dark:from-cyan-900/20 dark:to-blue-900/20 group-hover:from-cyan-500/20 group-hover:to-blue-500/20 dark:group-hover:from-cyan-900/30 dark:group-hover:to-blue-900/30 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors">
                        <item.icon className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-slate-800 dark:text-white mb-2 font-light tracking-wide">{item.label}</h4>
                        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-medium">{item.description}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-400 dark:text-slate-500 group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition-colors flex-shrink-0" />
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Logout Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-16 pt-12 border-t border-cyan-200/30 dark:border-cyan-900/20"
        >
          <button 
            onClick={handleLogout}
            className="w-full py-5 bg-red-50 dark:bg-red-950/30 hover:bg-red-100 dark:hover:bg-red-950/40 text-red-700 dark:text-red-400 rounded-2xl flex items-center justify-center gap-3 transition-all duration-300 border border-red-200 dark:border-red-900/30 hover:border-red-300 dark:hover:border-red-800/50 group shadow-lg shadow-red-100/30 dark:shadow-red-900/20"
          >
            <LogOut className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            <span className="tracking-[0.2em] text-[10px] font-bold uppercase">Sign Out</span>
          </button>
          
          <p className="text-center text-slate-500 dark:text-slate-500 text-[10px] tracking-[0.3em] font-medium mt-8 uppercase">
            Version 1.0.0 • Premium Edition
          </p>
        </motion.div>
      </div>
    </div>
  );
}