import { Link } from "react-router";
import { identityCards } from "../data/identityData";
import { Shield, Clock, CheckCircle2, Camera, Users, Crown, Settings, ChevronRight } from "lucide-react";
import { motion } from "motion/react";

export function Home() {
  return (
    <div className="bg-transparent min-h-screen transition-colors duration-500">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-b from-cyan-100/50 dark:from-cyan-950/30 to-transparent border-b border-cyan-200/30 dark:border-cyan-900/20">
        <div className="max-w-7xl mx-auto px-6 py-12 md:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-left md:text-center max-w-3xl mx-auto"
          >
            <div className="flex items-center gap-3 mb-4 md:justify-center">
              <div className="w-1.5 h-1.5 bg-green-500 dark:bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-[10px] bg-gradient-to-r from-green-600 to-cyan-600 bg-clip-text text-transparent tracking-[0.3em] uppercase font-bold">Secure Session Active</span>
            </div>
            <h1 className="text-4xl md:text-7xl text-slate-800 dark:text-white mb-4 tracking-tight font-light">
              Welcome back,
              <span className="block bg-gradient-to-r from-blue-600 via-cyan-600 to-green-600 bg-clip-text text-transparent mt-1">Professional</span>
            </h1>
            <p className="text-slate-600 dark:text-slate-300 text-base md:text-xl tracking-wide max-w-md md:mx-auto">
              Your digital credentials are encrypted and ready for verification.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Statistics Dashboard */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-blue-50 dark:from-blue-950/30 to-cyan-50 dark:to-cyan-900/10 border border-blue-200/50 dark:border-blue-900/20 rounded-2xl p-5 shadow-lg shadow-blue-100/50 dark:shadow-blue-900/20"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-blue-500/10 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
                <Shield className="w-5 h-5 text-blue-600 dark:text-cyan-400" />
              </div>
            </div>
            <h3 className="text-2xl text-slate-800 dark:text-white mb-0.5">{identityCards.length}</h3>
            <p className="text-[9px] text-slate-600 dark:text-slate-400 tracking-widest uppercase">Vault Items</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-green-50 dark:from-green-950/30 to-emerald-50 dark:to-emerald-900/10 border border-green-200/50 dark:border-green-900/20 rounded-2xl p-5 shadow-lg shadow-green-100/50 dark:shadow-green-900/20"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-green-500/10 dark:bg-green-900/30 rounded-xl flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <h3 className="text-2xl text-slate-800 dark:text-white mb-0.5">100%</h3>
            <p className="text-[9px] text-slate-600 dark:text-slate-400 tracking-widest uppercase">Verified</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-cyan-50 dark:from-cyan-950/30 to-blue-50 dark:to-blue-900/10 border border-cyan-200/50 dark:border-cyan-900/20 rounded-2xl p-5 col-span-2 md:col-span-1 shadow-lg shadow-cyan-100/50 dark:shadow-cyan-900/20"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-cyan-500/10 dark:bg-cyan-900/30 rounded-xl flex items-center justify-center">
                <Clock className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
              </div>
              <span className="text-[10px] text-green-600 dark:text-green-400 font-mono">LIVE</span>
            </div>
            <h3 className="text-2xl text-slate-800 dark:text-white mb-0.5">Global</h3>
            <p className="text-[9px] text-slate-600 dark:text-slate-400 tracking-widest uppercase">Uptime Monitor</p>
          </motion.div>
        </div>

        {/* Role-Based Access Cards */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-8">
            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-cyan-300/30 dark:via-cyan-900/20 to-transparent"></div>
            <h2 className="text-sm text-slate-700 dark:text-slate-300 tracking-[0.3em] uppercase font-extrabold">Access Portal</h2>
            <div className="h-px flex-1 bg-gradient-to-l from-transparent via-cyan-300/30 dark:via-cyan-900/20 to-transparent"></div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Employee Portal */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Link to="/employee" className="block group">
                <div className="relative bg-gradient-to-br from-blue-50 via-cyan-50 to-blue-100 dark:from-blue-950/50 dark:via-cyan-950/40 dark:to-blue-900/50 border-[3px] border-blue-300/70 dark:border-blue-700/50 rounded-[2rem] p-10 overflow-hidden hover:border-blue-500/90 dark:hover:border-blue-500/70 transition-all duration-500 shadow-2xl shadow-blue-200/50 dark:shadow-blue-900/40 hover:shadow-[0_20px_60px_-15px_rgba(59,130,246,0.5)] dark:hover:shadow-[0_20px_60px_-15px_rgba(59,130,246,0.3)] hover:scale-[1.03] active:scale-[0.98] backdrop-blur-xl">
                  {/* Enhanced Background decoration */}
                  <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-br from-blue-400/20 to-transparent rounded-full -mr-24 -mt-24 group-hover:scale-150 transition-transform duration-700"></div>
                  <div className="absolute bottom-0 left-0 w-40 h-40 bg-gradient-to-tr from-cyan-400/20 to-transparent rounded-full -ml-20 -mb-20 group-hover:scale-150 transition-transform duration-700"></div>
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-400/5 via-transparent to-cyan-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  
                  <div className="relative z-10">
                    {/* Header */}
                    <div className="flex items-center justify-between mb-8">
                      <div className="flex items-center gap-5">
                        <div className="w-20 h-20 bg-gradient-to-br from-blue-500 via-blue-600 to-cyan-600 rounded-[1.5rem] flex items-center justify-center shadow-2xl shadow-blue-500/40 group-hover:shadow-blue-500/60 group-hover:scale-110 transition-all duration-500">
                          <Users className="w-10 h-10 text-white" />
                        </div>
                        <div>
                          <h3 className="text-3xl text-slate-800 dark:text-white font-bold tracking-wide mb-2">Employee</h3>
                          <p className="text-sm text-blue-700 dark:text-blue-300 tracking-[0.2em] uppercase font-extrabold">Standard Access</p>
                        </div>
                      </div>
                      <ChevronRight className="w-8 h-8 text-blue-600 dark:text-blue-400 group-hover:translate-x-2 transition-transform duration-300" />
                    </div>

                    {/* Features */}
                    <div className="space-y-4 mb-8">
                      <div className="flex items-center gap-4">
                        <div className="w-3 h-3 bg-blue-500 rounded-full shadow-lg shadow-blue-500/50"></div>
                        <p className="text-base text-slate-700 dark:text-slate-200 font-semibold">View personal credentials</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-3 h-3 bg-cyan-500 rounded-full shadow-lg shadow-cyan-500/50"></div>
                        <p className="text-base text-slate-700 dark:text-slate-200 font-semibold">Scan & verify ID cards</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-3 h-3 bg-blue-500 rounded-full shadow-lg shadow-blue-500/50"></div>
                        <p className="text-base text-slate-700 dark:text-slate-200 font-semibold">Generate QR codes</p>
                      </div>
                    </div>

                    {/* Action Button */}
                    <div className="bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-600 text-white py-5 px-8 rounded-xl flex items-center justify-center gap-4 group-hover:from-blue-700 group-hover:via-blue-600 group-hover:to-cyan-700 group-hover:shadow-2xl group-hover:shadow-blue-500/50 transition-all duration-300 shadow-xl shadow-blue-500/30">
                      <Camera className="w-6 h-6" />
                      <span className="text-base tracking-[0.2em] uppercase font-extrabold">Access Portal</span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>

            {/* Higher Authority Portal */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Link to="/authority" className="block group">
                <div className="relative bg-gradient-to-br from-green-50 via-emerald-50 to-green-100 dark:from-green-950/50 dark:via-emerald-950/40 dark:to-green-900/50 border-[3px] border-green-300/70 dark:border-green-700/50 rounded-[2rem] p-10 overflow-hidden hover:border-green-500/90 dark:hover:border-green-500/70 transition-all duration-500 shadow-2xl shadow-green-200/50 dark:shadow-green-900/40 hover:shadow-[0_20px_60px_-15px_rgba(34,197,94,0.5)] dark:hover:shadow-[0_20px_60px_-15px_rgba(34,197,94,0.3)] hover:scale-[1.03] active:scale-[0.98] backdrop-blur-xl">
                  {/* Enhanced Background decoration */}
                  <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-br from-green-400/20 to-transparent rounded-full -mr-24 -mt-24 group-hover:scale-150 transition-transform duration-700"></div>
                  <div className="absolute bottom-0 left-0 w-40 h-40 bg-gradient-to-tr from-emerald-400/20 to-transparent rounded-full -ml-20 -mb-20 group-hover:scale-150 transition-transform duration-700"></div>
                  <div className="absolute inset-0 bg-gradient-to-br from-green-400/5 via-transparent to-emerald-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  
                  <div className="relative z-10">
                    {/* Header */}
                    <div className="flex items-center justify-between mb-8">
                      <div className="flex items-center gap-5">
                        <div className="w-20 h-20 bg-gradient-to-br from-green-500 via-green-600 to-emerald-600 rounded-[1.5rem] flex items-center justify-center shadow-2xl shadow-green-500/40 group-hover:shadow-green-500/60 group-hover:scale-110 transition-all duration-500">
                          <Crown className="w-10 h-10 text-white" />
                        </div>
                        <div>
                          <h3 className="text-3xl text-slate-800 dark:text-white font-bold tracking-wide mb-2">Higher Authority</h3>
                          <p className="text-sm text-green-700 dark:text-green-300 tracking-[0.2em] uppercase font-extrabold">Full Access</p>
                        </div>
                      </div>
                      <ChevronRight className="w-8 h-8 text-green-600 dark:text-green-400 group-hover:translate-x-2 transition-transform duration-300" />
                    </div>

                    {/* Features */}
                    <div className="space-y-4 mb-8">
                      <div className="flex items-center gap-4">
                        <div className="w-3 h-3 bg-green-500 rounded-full shadow-lg shadow-green-500/50"></div>
                        <p className="text-base text-slate-700 dark:text-slate-200 font-semibold">Manage all credentials</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-3 h-3 bg-emerald-500 rounded-full shadow-lg shadow-emerald-500/50"></div>
                        <p className="text-base text-slate-700 dark:text-slate-200 font-semibold">View analytics & reports</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-3 h-3 bg-green-500 rounded-full shadow-lg shadow-green-500/50"></div>
                        <p className="text-base text-slate-700 dark:text-slate-200 font-semibold">Approve & revoke access</p>
                      </div>
                    </div>

                    {/* Action Button */}
                    <div className="bg-gradient-to-r from-green-600 via-green-500 to-emerald-600 text-white py-5 px-8 rounded-xl flex items-center justify-center gap-4 group-hover:from-green-700 group-hover:via-green-600 group-hover:to-emerald-700 group-hover:shadow-2xl group-hover:shadow-green-500/50 transition-all duration-300 shadow-xl shadow-green-500/30">
                      <Settings className="w-6 h-6" />
                      <span className="text-base tracking-[0.2em] uppercase font-extrabold">Admin Dashboard</span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          </div>
        </div>

        {/* Add Card Button */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="w-full py-6 border border-dashed border-cyan-300/50 dark:border-cyan-800/40 rounded-2xl text-slate-500 dark:text-slate-400 hover:border-green-400/60 dark:hover:border-green-600/40 hover:text-green-600 dark:hover:text-green-400 transition-all duration-300 flex items-center justify-center gap-3 bg-gradient-to-br from-cyan-50/30 to-green-50/30 dark:from-cyan-950/10 dark:to-green-950/10 group backdrop-blur-sm"
        >
          <div className="w-8 h-8 rounded-full border border-cyan-300/50 dark:border-cyan-800/40 flex items-center justify-center group-hover:border-green-500 dark:group-hover:border-green-500 transition-colors bg-white/50 dark:bg-slate-900/50">
            <span className="text-xl font-light">+</span>
          </div>
          <span className="text-[10px] tracking-[0.3em] uppercase font-bold">Request New Access</span>
        </motion.button>
      </div>

      <div className="pb-20 md:pb-8"></div>
    </div>
  );
}