import { useParams, Link } from "react-router";
import { QRCodeSVG } from "qrcode.react";
import { identityCards } from "../data/identityData";
import { ArrowLeft, Shield, Clock, Sparkles } from "lucide-react";
import { useState, useEffect } from "react";
import { motion } from "motion/react";

export function QRCodeView() {
  const { cardId } = useParams<{ cardId: string }>();
  const [timeLeft, setTimeLeft] = useState(30);
  const card = identityCards.find((c) => c.id === cardId) || identityCards[0];

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          return 30; // Reset timer
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Generate QR data with card info
  const qrData = JSON.stringify({
    id: card.id,
    type: card.type,
    number: card.number,
    name: card.name,
    expiryDate: card.expiryDate,
    timestamp: Date.now(),
  });

  return (
    <div className="bg-transparent min-h-screen pb-20 md:pb-8 transition-colors duration-500">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-green-100/40 dark:from-green-950/20 to-transparent border-b border-green-200/30 dark:border-green-900/20">
        <div className="max-w-5xl mx-auto px-6 py-12">
          <Link to="/" className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors mb-8 group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] tracking-[0.2em] font-bold uppercase">Back to Dashboard</span>
          </Link>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl md:text-5xl text-slate-800 dark:text-white mb-4 tracking-tight font-light">
              Verification Portal
            </h1>
            <p className="text-slate-600 dark:text-slate-300 text-lg tracking-wide">{card.name}</p>
          </motion.div>
        </div>
      </div>

      {/* QR Code Section */}
      <div className="max-w-5xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* QR Code Display */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col items-center"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-green-400/20 to-cyan-400/20 dark:from-green-500/20 dark:to-cyan-500/20 blur-3xl opacity-50"></div>
              <div className="relative bg-white p-12 rounded-[2.5rem] shadow-2xl border border-cyan-200/50 dark:border-cyan-900/20">
                <QRCodeSVG
                  value={qrData}
                  size={280}
                  level="H"
                  includeMargin={true}
                  bgColor="#ffffff"
                  fgColor="#000000"
                />
              </div>
            </div>

            {/* Timer */}
            <div className="mt-8 flex items-center gap-4 bg-gradient-to-br from-green-50 to-cyan-50 dark:from-green-950/30 dark:to-cyan-950/30 border border-green-200/50 dark:border-green-900/20 rounded-2xl px-6 py-4 shadow-lg shadow-green-100/30 dark:shadow-green-900/20">
              <Clock className="w-6 h-6 text-green-600 dark:text-green-400" />
              <div>
                <p className="text-[9px] text-slate-500 dark:text-slate-400 tracking-[0.2em] uppercase font-bold mb-1">Auto-Refresh</p>
                <p className="text-2xl text-slate-800 dark:text-white font-light">
                  <span className="text-green-600 dark:text-green-400 font-medium">{timeLeft}</span> seconds
                </p>
              </div>
            </div>
          </motion.div>

          {/* Information Panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-8"
          >
            {/* Security Info */}
            <div className="bg-gradient-to-br from-cyan-50 dark:from-cyan-950/30 to-blue-50 dark:to-blue-900/10 border border-cyan-200/50 dark:border-cyan-900/20 rounded-2xl p-8 shadow-lg shadow-cyan-100/30 dark:shadow-cyan-900/20">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 bg-cyan-500/10 dark:bg-cyan-900/30 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm">
                  <Shield className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />
                </div>
                <div>
                  <h3 className="text-xl text-slate-800 dark:text-white mb-2 font-light tracking-wide">Enterprise Security</h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
                    This verification code employs military-grade encryption and automatically refreshes every 30 seconds to ensure maximum security.
                  </p>
                </div>
              </div>
            </div>

            {/* Features */}
            <div className="space-y-4 px-4">
              <div className="flex items-start gap-4">
                <div className="w-2 h-2 bg-green-500 dark:bg-green-400 rounded-full mt-2 shadow-sm"></div>
                <div>
                  <h4 className="text-slate-800 dark:text-white mb-1 tracking-wide font-medium">Encrypted Transmission</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-[10px] uppercase tracking-wider font-bold">End-to-end secure transfer</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-2 h-2 bg-cyan-500 dark:bg-cyan-400 rounded-full mt-2 shadow-sm"></div>
                <div>
                  <h4 className="text-slate-800 dark:text-white mb-1 tracking-wide font-medium">Time-Limited Access</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-[10px] uppercase tracking-wider font-bold">Automatic security expiration</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-2 h-2 bg-blue-500 dark:bg-blue-400 rounded-full mt-2 shadow-sm"></div>
                <div>
                  <h4 className="text-slate-800 dark:text-white mb-1 tracking-wide font-medium">Tamper-Proof</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-[10px] uppercase tracking-wider font-bold">Blockchain-verified authenticity</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Card Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-16 pt-12 border-t border-cyan-200/30 dark:border-cyan-900/20"
        >
          <div className="flex items-center gap-3 mb-8 px-4">
            <Sparkles className="w-5 h-5 text-green-600 dark:text-green-400" />
            <p className="text-slate-500 dark:text-slate-400 tracking-[0.2em] uppercase text-[10px] font-bold">Select Credential</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 px-4">
            {identityCards.map((c) => (
              <Link
                key={c.id}
                to={`/qr/${c.id}`}
                className={`p-6 rounded-2xl border transition-all duration-300 ${
                  c.id === card.id
                    ? "border-green-500 dark:border-green-500 bg-gradient-to-br from-green-50 to-cyan-50 dark:from-green-950/30 dark:to-cyan-950/30 shadow-lg shadow-green-200/30 dark:shadow-green-900/30"
                    : "border-cyan-200/40 dark:border-cyan-900/20 bg-white/90 dark:bg-slate-900/90 hover:border-green-400/60"
                }`}
              >
                <div className={`w-12 h-12 bg-gradient-to-br ${c.color} rounded-xl mb-6 shadow-md`}></div>
                <h4 className="text-slate-800 dark:text-white mb-1 font-medium tracking-wide">{c.name}</h4>
                <p className="text-slate-500 dark:text-slate-400 text-[8px] tracking-[0.2em] uppercase font-bold">{c.type.replace("-", " ")}</p>
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}