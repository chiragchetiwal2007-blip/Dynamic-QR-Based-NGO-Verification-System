import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { Home } from "./components/Home";
import { QRCodeView } from "./components/QRCodeView";
import { CardDetail } from "./components/CardDetail";
import { Settings } from "./components/Settings";
import { Login } from "./components/Login";
import { QRScanner } from "./components/QRScanner";
import { EmployeeDashboard } from "./components/EmployeeDashboard";
import { AuthorityDashboard } from "./components/AuthorityDashboard";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "qr/:cardId", Component: QRCodeView },
      { path: "card/:cardId", Component: CardDetail },
      { path: "settings", Component: Settings },
      { path: "scanner", Component: QRScanner },
      { path: "employee", Component: EmployeeDashboard },
      { path: "authority", Component: AuthorityDashboard },
    ],
  },
]);