export interface IdentityCard {
  id: string;
  type: "id-card" | "appointment-letter" | "membership-certificate";
  name: string;
  number: string;
  issueDate: string;
  expiryDate: string;
  issuingAuthority: string;
  photo?: string;
  additionalInfo: Record<string, string>;
  color: string;
}

export const identityCards: IdentityCard[] = [
  {
    id: "id-001",
    type: "id-card",
    name: "Government Issued ID",
    number: "ID-9456273819",
    issueDate: "2021-06-20",
    expiryDate: "2031-06-20",
    issuingAuthority: "National Identity Authority",
    additionalInfo: {
      nationality: "United States",
      bloodType: "O+",
    },
    color: "from-purple-500 to-purple-700",
  },
  {
    id: "mc-004",
    type: "membership-certificate",
    name: "NGO Network Membership",
    number: "MEM-NGO-45789",
    issueDate: "2023-03-01",
    expiryDate: "2025-03-01",
    issuingAuthority: "International NGO Alliance",
    additionalInfo: {
      membershipLevel: "Gold",
      region: "North America",
      votingRights: "Yes",
    },
    color: "from-amber-500 to-amber-700",
  },
  {
    id: "mc-005",
    type: "membership-certificate",
    name: "Humanitarian Workers Certificate",
    number: "MEM-HWC-92314",
    issueDate: "2022-11-20",
    expiryDate: "2026-11-20",
    issuingAuthority: "Global Humanitarian Network",
    additionalInfo: {
      membershipLevel: "Professional",
      specialization: "Disaster Relief",
      certificationStatus: "Active",
    },
    color: "from-red-500 to-red-700",
  },
];