
  # QR Digital Identity Wallet UI

  This is a code bundle for QR Digital Identity Wallet UI. The original project is available at https://www.figma.com/design/ZdHuJx9acnXnrADb2OMmC1/QR-Digital-Identity-Wallet-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  